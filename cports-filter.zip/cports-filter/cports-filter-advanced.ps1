param(
    [Parameter(Position = 0)]
    [string]$Path
)

$today = Get-Date -Format "dd-MM-yyyy"
$outputFile = Join-Path (Split-Path $Path -Parent) "$today.log"
Write-Host "--------"
Write-Host "The results will be written in $outputFile"
Write-Host "--------"
Start-Sleep -Seconds 2

if (Test-Path -Path .\$outputFile) {
    Write-Host "warning, there is already a file with name $outputFile. in the same directory"
    Write-Host "Please rename or move the existing $outputFile file" -ForegroundColor red
    break
}
if (-not $Path) {
    Write-Host "No file path provided."
    Write-Host "`nUsage example:"
    Write-Host "    .\cports-filter-advanced.ps1 'C:\Logs\cports.log'"
    Start-Sleep -Seconds 0.5
    exit 1
}

try {
    if (-not (Test-Path $Path)) {
        throw "The system cannot find the file '$Path'"
    }

    $lines = Get-Content -Path $Path -ErrorAction Stop

    Write-Host "Successfully read $($lines.Count) lines from: $Path"
    Start-Sleep -Seconds 5
    Clear-Host
}
catch {
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "`nUsage example:"
    Write-Host "    .\cports_file_filter.ps1 'C:\Logs\cports_running.log'" -ForegroundColor Cyan
    Start-Sleep -Seconds 1
    exit 1
}

# Exclusions array - should be updated regularly by the compliance testers!
$excludeList = @(
    'removed',                    # Ignored/removed entries
    'mpcmdrun',                   # Microsoft Defender scan tool
    'xagt.exe',                   # Trellix agent
    'ZSATray',                    # Zscaler tray app
    'wireshark.exe',              # Network sniffer
    'edgeupdate',                 # Edge updater
    'nessus-agent',               # Nessus scan agent
    'widgetsmicrosoft.management',# Windows Widgets service
    'ndlaunch',                   # NetDocuments launcher
    'PFERemediation',             # Defender remediation
    'OneDrive',                   # File sync client
    'msedge',                     # Edge browser
    'widgets',                    # Windows 11 widgets
    'msmpeng',                    # Microsoft Defender AV engine
    'wireshark',                  # Wireshark Network analyzer
    'runtimebroker',              # UWP permissions manager
    'dsregcmd',                   # Microsoft Azure AD join tool
    'StartMenuExperienceHost',    # Start Menu process
    'MFEConsole',                 # McAfee AV Process 
    'MoUsoCoreWorker'             # Windows Update Process  
)

$excludePattern = '(?i)' + ($excludeList -join '|')

# Define subnets
$subnets = @(
    @{IP='10.252.76.0'; Mask='255.255.255.0'},
    @{IP='10.252.78.0'; Mask='255.255.255.0'},
    @{IP='194.114.63.0'; Mask='255.255.255.0'},
    @{IP='10.253.53.0'; Mask='255.255.255.0'},
    @{IP='10.253.1.0'; Mask='255.255.255.0'}
)

# Test if the IP 
function Test-IPInSubnet {
    param (
        [string]$IP,
        [string]$SubnetIP,
        [string]$SubnetMask
    )

    $ipAddr = [System.Net.IPAddress]::Parse($IP)
    $subnetAddr = [System.Net.IPAddress]::Parse($SubnetIP)
    $maskAddr = [System.Net.IPAddress]::Parse($SubnetMask)

    $ipBytes = $ipAddr.GetAddressBytes()
    $subnetBytes = $subnetAddr.GetAddressBytes()
    $maskBytes = $maskAddr.GetAddressBytes()

    for ($i = 0; $i -lt $ipBytes.Length; $i++) {
        if (($ipBytes[$i] -band $maskBytes[$i]) -ne ($subnetBytes[$i] -band $maskBytes[$i])) {
            return $false
        }
    }
    return $true
}

# Process lines
Get-Content -Path $Path | Where-Object { $_ -notmatch $excludePattern } | ForEach-Object {
    # Remove #number
    $line = $_ -replace '#\d+\s*', ''

    # Extract destination IP from pattern "-> IP :port"
    if ($line -match '->\s+([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)') {
        $destIP = $matches[1]
        $isProxy = $false

        # Check if destination IP is in any subnet
        foreach ($subnet in $subnets) {
            if (Test-IPInSubnet -IP $destIP -SubnetIP $subnet.IP -SubnetMask $subnet.Mask) {
                $isProxy = $true
                break
            }
        }

        # Add comment if proxy
        if ($isProxy) {
            "$line  #proxy-connection"
        } else {
            $line
        }
    } else {
        #Lines without IP just output as-is
        $line
    } 
} | Tee-Object -FilePath $outputFile -Append

Write-Host "--------"
Write-Host  "Wrote $((Get-Content -Path $outputFile -ErrorAction SilentlyContinue).Count) processed log lines to a $outputfile"
